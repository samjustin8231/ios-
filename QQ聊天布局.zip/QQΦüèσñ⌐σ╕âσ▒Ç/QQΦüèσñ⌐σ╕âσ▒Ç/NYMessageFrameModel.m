//
//  NYMessageFrameModel.m
//  QQ聊天布局
//
//  Created by apple on 15-4-11.
//  Copyright (c) 2015年 znycat. All rights reserved.
//

#import "NYMessageFrameModel.h"
#import "NYMessageModel.h"
#import "Constant.h"


@implementation NYMessageFrameModel

/**这里的思路是有个Frame的模型，里面有message模型，
    我们返回的时Frame的一个数组，里面的每一个frame都有一个message，并且在调用的时候我们就调用frame的setMseeage方法，将从而将这个frame的其他的比如cellH等等属性设置好，这样我们的frame里面的数据边全面了，返回的是一个frame的array，其他人可以拿来直接就用了。
 */
+(NSMutableArray *) messageFrames
{
        NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"messages.plist" ofType:nil]];
        NSMutableArray *arrayM = [NSMutableArray array];
        for (NSDictionary *dict in array) {
            NYMessageFrameModel * messageFrame = [[NYMessageFrameModel alloc] init];
            //这时候 arrayM中得最后一个就是前一个。
            NYMessageFrameModel *lastFrame = [arrayM lastObject];
            //当前要加进去的Frame
            NYMessageModel *message =[NYMessageModel messageWithDict:dict];
            message.hideTime = [message.time isEqualToString:lastFrame.message.time];
            
            messageFrame.message = message;
            
            [arrayM addObject:messageFrame];
        }
        return arrayM;
}

-(void)setMessage:(NYMessageModel *)message
{
    _message = message;
    
    //定义间距
    CGFloat padding = 10;
    
    //设置时间位置
    if (!message.hideTime) {
        CGFloat timeX = 0;
        CGFloat timeY = 0;
        CGFloat timeW = bScreenWidth;
        CGFloat timeH = bNormalH;
        _timeF = CGRectMake(timeX, timeY, timeW, timeH);
    }
    
    
    //设置头像位置
    CGFloat iconX;
    CGFloat iconY = CGRectGetMaxY(_timeF) + padding;
    CGFloat iconW = bIconW;
    CGFloat iconH = bIconH;
    if (message.type == NYMessagesModelTypeGatsby) {//自己发的
        iconX = bScreenWidth - padding - iconW;
    }else{//别人发的
        iconX = padding ;
    }
    _iconF = CGRectMake(iconX, iconY, iconW, iconH);
    
    //设置正文位置
    CGFloat textX ;
    CGFloat textY = iconY;
    CGSize textRealSize = [message.text boundingRectWithSize:CGSizeMake(150, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:bBtnFont} context:nil].size;

    CGSize btnSize = CGSizeMake(textRealSize.width + 40, textRealSize.height + 40);
    
    if (message.type == NYMessagesModelTypeGatsby) {
        textX = bScreenWidth -padding - iconW - padding - btnSize.width;
    }else{
        textX = padding + iconW + padding;
    }
    
//    _textF = CGRectMake(textX, textY, textRealSize.width, textRealSize.height);
    _textF = (CGRect){{textX, textY},btnSize};
    
    //cell 的高
    CGFloat iconMaxY = CGRectGetMaxY(_iconF);
    CGFloat textMaxY = CGRectGetMaxY(_textF);
    _cellH = MAX(iconMaxY, textMaxY);
    
}
@end
