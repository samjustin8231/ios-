//
//  NYMessageCell.h
//  QQ聊天布局
//
//  Created by apple on 15-4-11.
//  Copyright (c) 2015年 znycat. All rights reserved.
//

#import <UIKit/UIKit.h>
@class  NYMessageFrameModel;
@interface NYMessageCell : UITableViewCell
@property (nonatomic, strong) NYMessageFrameModel *messageFrame;

+(instancetype)messageCellWithTableView:(UITableView *)tableView;
@end
