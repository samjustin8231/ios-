//
//  Constant.h
//  01-QQ聊天界面
//
//  Created by apple on 14-8-22.
//  Copyright (c) 2014年 itcast. All rights reserved.
//


#define bScreenWidth [[UIScreen mainScreen] bounds].size.width

#define bNormalH 44

#define bIconW 50

#define bIconH 50

#define bBtnFont [UIFont systemFontOfSize:15.0f]