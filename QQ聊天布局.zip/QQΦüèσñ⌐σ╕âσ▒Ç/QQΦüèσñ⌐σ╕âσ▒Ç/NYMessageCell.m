//
//  NYMessageCell.m
//  QQ聊天布局
//
//  Created by apple on 15-4-11.
//  Copyright (c) 2015年 znycat. All rights reserved.
//

#import "NYMessageCell.h"
#import "NYMessageModel.h"
#import "NYMessageFrameModel.h"
#import "Constant.h"
#import "UIImage+ResizImage.h"

@interface NYMessageCell()
//时间
@property (nonatomic, weak) UILabel *timeView;
//正文
@property (nonatomic, weak) UIButton *textView;
//头像
@property (nonatomic, weak) UIImageView *iconView;


@end

@implementation NYMessageCell

//用set方法来设置各个组件的位置
-(void)setMessageFrame:(NYMessageFrameModel *)messageFrame{
    _messageFrame = messageFrame;
//    时间位置
    _timeView.frame = messageFrame.timeF;
      //头像位置
    _iconView.frame = messageFrame.iconF;
    
    //正文位置
    _textView.frame = messageFrame.textF;
    
//    设置时间内容
    NYMessageModel *model = messageFrame.message;
    _timeView.text = model.time;
    //头像内容
    if (model.type == NYMessagesModelTypeGatsby) {
        self.iconView.image = [UIImage imageNamed:@"Gatsby"];
    }else{
        self.iconView.image = [UIImage imageNamed:@"Jobs"];
    }
    //正文内容 这里是按钮，不能用点语法，因为他有好多状态。
    [self.textView setTitle:model.text forState:UIControlStateNormal];
    //设置正文背景图片
    if (model.type == NYMessagesModelTypeGatsby) {
        [self.textView setBackgroundImage:[UIImage resizeWithImageName:@"chat_send_nor"] forState:UIControlStateNormal];

    }else{
        //设置正文的背景图片
        [self.textView setBackgroundImage:[UIImage resizeWithImageName:@"chat_recive_nor"] forState:UIControlStateNormal];
    }
    
}



+(instancetype)messageCellWithTableView:(UITableView *)tableView
{
    static NSString *ID = @"messageCell";
    NYMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[self alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    
    return cell;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        
        
        //1时间
        UILabel *time = [[UILabel alloc]init];
        time.textAlignment = NSTextAlignmentCenter;
        time.font = [UIFont systemFontOfSize:13.0f];
        [self.contentView addSubview:time];
        self.timeView = time;
        
        
        //正文
        UIButton *text = [[UIButton alloc]init];
        text.titleLabel.font = bBtnFont;
        text.titleLabel.numberOfLines = 0;//自动换行
        text.contentEdgeInsets = UIEdgeInsetsMake(20, 20, 20, 20);//设置按钮文字的内边距
        [text setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];//设置文字颜色
        [self.contentView addSubview:text];
        self.textView = text;
        
        //头像
        UIImageView *icon = [[UIImageView alloc]init];
        [self.contentView addSubview:icon];
        self.iconView = icon;
        
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
