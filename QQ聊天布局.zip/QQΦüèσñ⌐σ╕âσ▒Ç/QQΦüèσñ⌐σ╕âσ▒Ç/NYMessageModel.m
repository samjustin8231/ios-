//
//  NYMessageModel.m
//  QQ聊天布局
//
//  Created by apple on 15-4-11.
//  Copyright (c) 2015年 znycat. All rights reserved.
//

#import "NYMessageModel.h"

@implementation NYMessageModel

- (instancetype)initWithDict:(NSDictionary *)dict
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+(instancetype)messageWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}




@end
