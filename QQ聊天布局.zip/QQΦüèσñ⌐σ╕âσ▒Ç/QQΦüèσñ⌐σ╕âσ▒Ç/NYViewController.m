//
//  NYViewController.m
//  QQ聊天布局
//
//  Created by apple on 15-4-10.
//  Copyright (c) 2015年 znycat. All rights reserved.
//

#import "NYViewController.h"
#import "NYMessageCell.h"
#import "NYMessageModel.h"
#import "NYMessageFrameModel.h"

@interface NYViewController ()

@property (nonatomic, strong) NSMutableArray *messageFrames;
@property (weak,nonatomic)IBOutlet UITableView *tableView;
/**输入框*/
@property (weak, nonatomic) IBOutlet UITextField *inputView;

/**自动回复数组*/
@property (nonatomic, strong)NSDictionary *autoReplay;
@end

@implementation NYViewController

//懒加载自动回复
- (NSDictionary *)autoReplay
{
    if (_autoReplay == nil) {
        _autoReplay  = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"autoReplay.plist" ofType:nil]];
    }
    
    return _autoReplay;
}

-(NSMutableArray *)messageFrames{
    if (_messageFrames == nil) {
        _messageFrames = [NYMessageFrameModel messageFrames];
    }
    return _messageFrames;
}

/**隐藏状态栏*/
-(BOOL)prefersStatusBarHidden
{
    return YES;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    //设置cell不可选中
    self.tableView.allowsSelection = NO;
	//设置背景颜色，要将cell颜色清空
    self.tableView.backgroundColor = [UIColor colorWithRed:225/255.0 green:225/255.0 blue:225/255.0 alpha:1.0];
    
    //移除分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    //监听通知中心 监听keyboardChange
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    //设置输入框的左边距
    self.inputView.leftView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 8, 0)];
    //设置一直显示
    self.inputView.leftViewMode = UITextFieldViewModeAlways;

    
}

-(void)keyboardDidChangeFrame:(NSNotification *)noti
{
    //改变window的背景颜色
    self.view.window.backgroundColor = self.tableView.backgroundColor;
    
    //  键盘退出的frame
    CGRect frame = [noti.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    
    //键盘实时y
    CGFloat keyY = frame.origin.y;
    
    //屏幕的高度
    CGFloat screenH = [[UIScreen mainScreen] bounds].size.height;
    
    //动画时间
    CGFloat keyDuration = [noti.userInfo[UIKeyboardAnimationDurationUserInfoKey] floatValue];
    
    //执行动画
    [UIView animateWithDuration:keyDuration animations:^{
        self.view.transform = CGAffineTransformMakeTranslation(0, keyY - screenH);
    }];

}

//当tableview 滚动的时候 结束编辑事件  （退出键盘）
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - tableView数据源方法
/**行数*/
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.messageFrames.count;
}
/**cell*/
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NYMessageCell *cell = [NYMessageCell messageCellWithTableView:tableView];
    NYMessageFrameModel * messageFrame = self.messageFrames[indexPath.row];
    
    cell.messageFrame = messageFrame;
    return cell;
}

#pragma mark - tableView代理方法
/**每个cell的高度*/
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [self.messageFrames[indexPath.row] cellH];
}
#pragma mark - UITextField代理方法

/**直接return YES即可实现在输入框输入文字，然后按下return 然后textField.text便出现内容*/
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //1，发送一条数据。
    [self addMessage:textField.text type:NYMessagesModelTypeGatsby];
    
    //自动回复
    NSString *autoStr = [self autoReplayWithText:textField.text];
    //将自动回复添加成一天聊天信息
    [self addMessage:autoStr type:NYMessagesModelTypeJobs];
    
    return YES;
}

//自动回复一条聊天信息
- (NSString *)autoReplayWithText:(NSString *)text
{
    //3自动回复
    for (int a = 0 ; a < text.length; a++) {
        
        NSString *subStr = [text substringWithRange:NSMakeRange(a, 1)];
        
        if (self.autoReplay[subStr]) {
            return  self.autoReplay[subStr];
        }
    }
    
    return @"滚蛋吗0";
}

//发送一条数据。
-(void)addMessage:(NSString *)text type:(NYMessagesModelType)type

{
    
    //如果内容为空，那么就直接返回
    if (text == nil) {
        return ;
    }
    //1，添加模型数据
    NYMessageModel *message = [[NYMessageModel alloc]init];
    //设置数据的值
    message.time = @"16:88";
    message.text = text;
    message.type = type;
    //设置内容的frame
    NYMessageFrameModel * fm = [[NYMessageFrameModel alloc]init];
    //将模型设置给frame
    fm.message = message;
    
    //添加到数值
    [self.messageFrames addObject:fm];
    
    //2,刷新表格
    [self.tableView reloadData];
    //关闭键盘
    [self scrollViewWillBeginDragging:self.tableView];
    //清空输入框的内容
    self.inputView.text = @"";
    
    //3,自动上移
    //移动的位置
    NSIndexPath *path = [NSIndexPath indexPathForRow:self.messageFrames.count - 1 inSection:0];
    //真正去的位置 atatScrollPosition ：滚到得位置
    [self.tableView scrollToRowAtIndexPath:path atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}
@end