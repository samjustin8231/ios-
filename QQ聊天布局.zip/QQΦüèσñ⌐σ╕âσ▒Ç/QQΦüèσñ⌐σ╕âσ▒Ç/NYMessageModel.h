//
//  NYMessageModel.h
//  QQ聊天布局
//
//  Created by apple on 15-4-11.
//  Copyright (c) 2015年 znycat. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef enum{
    NYMessagesModelTypeGatsby = 0,
    NYMessagesModelTypeJobs
} NYMessagesModelType;

@interface NYMessageModel : NSObject

@property (nonatomic, copy) NSString *text;
@property (nonatomic, copy) NSString *time;

/**发送类型*/
@property (nonatomic, assign) NYMessagesModelType type;
/**是否隐藏时间*/
@property (nonatomic, assign) BOOL hideTime;

-(instancetype)initWithDict:(NSDictionary *)dict;
+(instancetype)messageWithDict:(NSDictionary *)dict;



@end
