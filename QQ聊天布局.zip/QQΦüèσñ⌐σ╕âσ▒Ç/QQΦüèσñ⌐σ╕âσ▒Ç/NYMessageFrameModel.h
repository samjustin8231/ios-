//
//  NYMessageFrameModel.h
//  QQ聊天布局
//
//  Created by apple on 15-4-11.
//  Copyright (c) 2015年 znycat. All rights reserved.
//

#import <Foundation/Foundation.h>
@class NYMessageModel;

@interface NYMessageFrameModel : NSObject

@property (nonatomic, assign, readonly) CGRect textF;

@property (nonatomic, assign, readonly) CGRect timeF;

@property (nonatomic, assign, readonly) CGRect iconF;

@property (nonatomic, assign, readonly) CGFloat cellH;

@property (nonatomic, strong) NYMessageModel *message;

+(NSMutableArray *) messageFrames;
@end
