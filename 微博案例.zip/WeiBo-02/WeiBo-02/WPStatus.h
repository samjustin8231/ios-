//
//  WPStatus.h
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-28.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WPStatus : NSObject
@property(nonatomic,copy) NSString *icon;
@property(nonatomic,copy) NSString *name;
@property(nonatomic,assign) BOOL vip;
@property(nonatomic,copy) NSString *text;
@property(nonatomic,copy) NSString *picture;

-(instancetype)initWithDict:(NSDictionary *)dict;
+(instancetype)statusWithDict:(NSDictionary *)dict;
@end
