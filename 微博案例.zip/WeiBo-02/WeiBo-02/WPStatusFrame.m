//
//  WPStatusFrame.m
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-28.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import "WPStatusFrame.h"
#import "WPStatus.h"

@implementation WPStatusFrame

-(void)setStatus:(WPStatus *)status{
    _status=status;
    
    CGFloat padding=10;
    
    CGFloat iconX=padding;
    CGFloat iconY=padding;
    CGFloat iconW=30;
    CGFloat iconH=30;
    _iconF=CGRectMake(iconX, iconY, iconW, iconH);
    
    CGFloat nameX=CGRectGetMaxX(_iconF)+padding;
    CGSize nameMaxSize=CGSizeMake(MAXFLOAT, MAXFLOAT);
    NSDictionary *nameAttr=@{NSFontAttributeName:[UIFont systemFontOfSize:14]};
    CGSize nameSize=[self.status.name boundingRectWithSize:nameMaxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:nameAttr context:nil].size;
    CGFloat nameY=iconY+(iconH-nameSize.height)*0.5;
    _nameF=CGRectMake(nameX, nameY, nameSize.width, nameSize.height);
    
    CGFloat vipX=CGRectGetMaxX(_nameF)+padding;
    CGFloat vipY=nameY;
    CGFloat vipW=14;
    CGFloat vipH=14;
    _vipF=CGRectMake(vipX, vipY, vipW, vipH);
    
    CGFloat textX=iconX;
    CGFloat textY=CGRectGetMaxY(_iconF)+padding;
    CGSize textMaxSize=CGSizeMake(300, MAXFLOAT);
    NSDictionary *textAttr=@{NSFontAttributeName:[UIFont systemFontOfSize:15]};
    CGSize textSize=[self.status.text boundingRectWithSize:textMaxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:textAttr context:nil].size;
    _textF=CGRectMake(textX, textY, textSize.width, textSize.height);
    
    if (self.status.picture) {
        CGFloat pictureX=textX;
        CGFloat pictureY=CGRectGetMaxY(_textF)+padding;
        CGFloat pictureW=100;
        CGFloat pictureH=100;
        _pictureF=CGRectMake(pictureX, pictureY, pictureW, pictureH);
        
        _cellHeight=CGRectGetMaxY(_pictureF)+padding;
    }else{
        _cellHeight=CGRectGetMaxY(_textF)+padding;
    }
}

@end
