//
//  ViewController.h
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-27.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController


@end

