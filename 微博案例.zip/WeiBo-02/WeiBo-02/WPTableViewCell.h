//
//  WPTableViewCell.h
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-28.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WPStatusFrame.h"

@interface WPTableViewCell : UITableViewCell

@property(nonatomic,strong) WPStatusFrame *statusFrame;
+(instancetype)cellWithTableView:(UITableView *)tableView;

@end
