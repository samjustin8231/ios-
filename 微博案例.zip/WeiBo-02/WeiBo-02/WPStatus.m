//
//  WPStatus.m
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-28.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import "WPStatus.h"

@implementation WPStatus


-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self=[super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+(instancetype)statusWithDict:(NSDictionary *)dict{
    return [[self alloc]initWithDict:dict];
}

@end
