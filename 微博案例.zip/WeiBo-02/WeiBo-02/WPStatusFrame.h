//
//  WPStatusFrame.h
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-28.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class WPStatus;

@interface WPStatusFrame : NSObject
@property(nonatomic,assign,readonly) CGRect iconF;
@property(nonatomic,assign,readonly) CGRect nameF;
@property(nonatomic,assign,readonly) CGRect vipF;
@property(nonatomic,assign,readonly) CGRect textF;
@property(nonatomic,assign,readonly) CGRect pictureF;
@property(nonatomic,assign,readonly) CGFloat cellHeight;
@property(nonatomic,strong) WPStatus *status;
@end
