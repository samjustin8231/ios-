//
//  ViewController.m
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-27.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import "ViewController.h"
#import "WPStatusFrame.h"
#import "WPStatus.h"
#import "WPTableViewCell.h"

@interface ViewController ()
@property(nonatomic,strong) NSArray *statusFrames;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(BOOL)prefersStatusBarHidden{
    return YES;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.statusFrames.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    WPTableViewCell *cell=[WPTableViewCell cellWithTableView:tableView];
    cell.statusFrame=self.statusFrames[indexPath.row];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    WPStatusFrame *statueFrame=self.statusFrames[indexPath.row];
    return statueFrame.cellHeight;
}

-(NSArray *)statusFrames{
    if (_statusFrames==nil) {
        NSString *path=[[NSBundle mainBundle]pathForResource:@"statuses.plist" ofType:nil];
        NSArray *statusArray=[NSArray arrayWithContentsOfFile:path];
        NSMutableArray *muArray=[[NSMutableArray alloc]init];
        for (NSDictionary *dict in statusArray) {
            WPStatus *status=[WPStatus statusWithDict:dict];
            WPStatusFrame *statusFrame=[[WPStatusFrame alloc]init];
            statusFrame.status=status;
            [muArray addObject:statusFrame];
        }
        _statusFrames=muArray;
    }
    return _statusFrames;
}

@end
