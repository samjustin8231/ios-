//
//  WPTableViewCell.m
//  WeiBo-02
//
//  Created by 魏素宝 on 14-10-28.
//  Copyright (c) 2014年 魏素宝. All rights reserved.
//

#import "WPTableViewCell.h"
#import "WPStatus.h"

@interface WPTableViewCell()
@property(nonatomic,weak) UIImageView *iconView;
@property(nonatomic,weak) UILabel *nameView;
@property(nonatomic,weak) UIImageView *vipView;
@property(nonatomic,weak) UILabel *textView;
@property(nonatomic,weak) UIImageView *pictureView;
@end

@implementation WPTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        UIImageView *iconView=[[UIImageView alloc]init];
        [self.contentView addSubview:iconView];
        self.iconView=iconView;
        
        UILabel *nameView=[[UILabel alloc]init];
        nameView.font=[UIFont systemFontOfSize:14];
        [self.contentView addSubview:nameView];
        self.nameView=nameView;
        
        UIImageView *vipView=[[UIImageView alloc]init];
        vipView.image=[UIImage imageNamed:@"vip"];
        [self.contentView addSubview:vipView];
        self.vipView=vipView;
        
        UILabel *textView=[[UILabel alloc]init];
        textView.font=[UIFont systemFontOfSize:15];
        textView.numberOfLines=0;
        [self.contentView addSubview:textView];
        self.textView=textView;
        
        UIImageView *pictureView=[[UIImageView alloc]init];
        [self.contentView addSubview:pictureView];
        self.pictureView=pictureView;
    }
    return self;
}

+(instancetype)cellWithTableView:(UITableView *)tableView{
    static NSString *ID=@"status";
    WPTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:ID];
    if (cell==nil) {
        cell=[[WPTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    return cell;
}

-(void)setStatusFrame:(WPStatusFrame *)statusFrame{
    _statusFrame=statusFrame;
    [self settingData];
    [self settingFrame];
}

-(void)settingData{
    WPStatus *status=self.statusFrame.status;
    self.iconView.image=[UIImage imageNamed:status.icon];
    self.nameView.text=status.name;
    if (status.vip) {
        self.vipView.hidden=NO;
    }else{
        self.vipView.hidden=YES;
    }
    self.textView.text=status.text;
    if (status.picture) {
        self.pictureView.hidden=NO;
        self.pictureView.image=[UIImage imageNamed:status.picture];
    }else{
        self.pictureView.hidden=YES;
    }
}

-(void)settingFrame{
    self.iconView.frame=self.statusFrame.iconF;
    self.nameView.frame=self.statusFrame.nameF;
    if (self.statusFrame.status.vip) {
        self.vipView.frame=self.statusFrame.vipF;
    }
    self.textView.frame=self.statusFrame.textF;
    if (self.statusFrame.status.picture) {
        self.pictureView.frame=self.statusFrame.pictureF;
    }
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
